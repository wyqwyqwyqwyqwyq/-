# mysql结果返回
from base.dbhelper import DBHelper


def mysqlReturn(sql):
    mysql_db = DBHelper()
    return mysql_db.select(sql)

